// Copyright (C) 2015 André Bargull. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
es6id: B.2.3.5
description: >
  String.prototype.bold.name is "bold".
info: >
  String.prototype.bold ( )

  17 ECMAScript Standard Built-in Objects:
    Every built-in Function object, including constructors, that is not
    identified as an anonymous function has a name property whose value
    is a String.

    Unless otherwise specified, the name property of a built-in Function
    object, if it exists, has the attributes { [[Writable]]: false,
    [[Enumerable]]: false, [[Configurable]]: true }.
includes: [propertyHelper.js]
---*/

assert.sameValue(String.prototype.bold.name, "bold");

verifyNotEnumerable(String.prototype.bold, "name");
verifyNotWritable(String.prototype.bold, "name");
verifyConfigurable(String.prototype.bold, "name");
